<?php
	echo 
	"asdasd";
	exit;
?>